This folder contains customized overrides for this demo application. These
include the overrides for managers, startup/activate and shutdown actions.
